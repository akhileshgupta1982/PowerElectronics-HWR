function Vchange(){
   Vm=document.getElementById("Vp").value;
document.getElementById("Voltage_amplitude").value=Vm;

}
