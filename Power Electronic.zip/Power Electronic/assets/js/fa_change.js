function FAG(){
   fir=document.getElementById("FA").value;
    document.getElementById("FAN").value=fir;
	
}