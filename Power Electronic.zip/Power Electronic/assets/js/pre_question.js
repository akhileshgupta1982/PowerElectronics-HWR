

const quiz = [
	{
		q:'When a thyristor if forward biased, the number of blocked p-n junctions is',
		options:['1','2','3','4'],
		answer:0
	},
	{
		q:'In a thyristor',
		options:['Latching current IL is associated with turn-off process and holding current IH with turn-on process','Both IL and IH are associated with turn-off process','IH is associated with turn-off process and IL with turn-on process.','Both IL and IH are associated with turn-off process'],
		answer:2
	},
	{
		q:'In a thyristor, the ratio of holding current to latching current is',
		options:['0.4','1.0','2.5','4.0'],
		answer:0
	},
	{
		q:'The SCR ratings, di/dt in A/µsec and dv/dt in V/µsec, may vary, respectively, between',
		options:['20 to 500, 10 to 100','Both 20 to 500','Both 10 to 100','50 to 300, 20 to 500'],
		answer:1
	},
	{
		q:'When a thyristor if forward biased, the number of blocked p-n junctions is',
		options:['1','2','3','4'],
		answer:1
	}

]