function Frq(){
   fr=document.getElementById("fo").value;
    document.getElementById("Frequency").value=fr;
	
}
function Vmax(){
   V_range=document.getElementById("Vmax").value;
    document.getElementById("V_max").value= V_range;
	
}