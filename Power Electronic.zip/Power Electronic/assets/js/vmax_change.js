function Vrange(){
   V_range=document.getElementById("Vmax").value;
    document.getElementById("V_max").value= V_range;
	
}
function Trange(){
   T_range=document.getElementById("Tmax").value;
    document.getElementById("T_max").value= T_range;
	
}